### Installation

To install and start the CM dashboard, run the following commands:

```bash
git clone https://github.com/Mrvexyplays/CM- && cd Oversee && npm install && npm run seed && npm run createUser && node .
```

### Notes

- Stay tuned for updates as Discord login is in progress.
- Created with ❤️ by **Mr Vexy**.
