const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ComponentType,
} = require("discord.js");

module.exports = (client) => {
    client.riffy.on("trackStart", async (player, track) => {
        const channel = client.channels.cache.get(player.textChannel);
        if (!channel) return;

        if (!track.info.requester) track.info.requester = client.user;

        const duration = formatDuration(track.info.length);

        const embed = new EmbedBuilder()
            .setTitle("Now Playing")
            .setURL(track.info.uri)
            .setThumbnail(track.info.artworkUrl || track.info.thumbnail || "https://i.imgur.com/3ZUrjUP.png")
            .addFields({
                name: "<a:music:1380153983682740255> Song Info",
                value:
                    `> <:dot:1380133992929562766> **Name:** [${track.info.title}](${track.info.uri})\n` +
                    `> <:dot:1380133992929562766> **Uploader:** ${track.info.author || "Unknown"}\n` +
                    `> <:dot:1380133992929562766> **Duration:** ${duration}`,
            })
            .setFooter({
                text: `Requested By ${track.info.requester?.tag || "Unknown"}`,
                iconURL: track.info.requester?.displayAvatarURL?.() || client.user.displayAvatarURL(),
            });

        const getButtons = (paused) => {
            const row = new ActionRowBuilder();

            if (paused) {
                row.addComponents(
                    new ButtonBuilder().setCustomId("resume").setLabel("Resume").setStyle(ButtonStyle.Secondary)
                );
            } else {
                row.addComponents(
                    new ButtonBuilder().setCustomId("pause").setLabel("Pause").setStyle(ButtonStyle.Secondary)
                );
            }

            row.addComponents(
                new ButtonBuilder().setCustomId("stop").setLabel("Stop").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("skip").setLabel("Skip").setStyle(ButtonStyle.Secondary)
            );

            return [row];
        };

        let isPaused = false;
        const message = await channel.send({ embeds: [embed], components: getButtons(isPaused) });

        const collector = message.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: track.info.length,
        });

        collector.on("collect", async (interaction) => {
            if (interaction.user.bot) return;

            switch (interaction.customId) {
                case "pause":
                    player.pause(true);
                    isPaused = true;
                    await interaction.update({ components: getButtons(isPaused) });
                    break;

                case "resume":
                    player.pause(false);
                    isPaused = false;
                    await interaction.update({ components: getButtons(isPaused) });
                    break;

                case "stop":
                    if (player.setRepeatMode) {
                        player.setRepeatMode(0);
                    } else if (player.setTrackRepeat && player.setQueueRepeat) {
                        player.setTrackRepeat(false);
                        player.setQueueRepeat(false);
                    } else {
                        player.loop = "off";
                    }

                    player.isAutoplay = false;

                    player.stop();
                    collector.stop();

                    await interaction.update({
                        content: "<:pause:1380134770553520149> Stopped. Autoplay & loop disabled.",
                        components: [],
                    });
                    break;

                case "skip":
                    if (player.setRepeatMode) {
                        player.setRepeatMode(0);
                    } else if (player.setTrackRepeat && player.setQueueRepeat) {
                        player.setTrackRepeat(false);
                        player.setQueueRepeat(false);
                    } else {
                        player.loop = "off";
                    }

                    if (typeof player.skip === "function") {
                        player.skip();
                    } else {
                        player.stop();
                    }

                    collector.stop();

                    await interaction.update({
                        content: "<:next:1380134811261636658> Skipped.",
                        components: [],
                    });
                    break;
            }
        });

        collector.on("end", async () => {
            try {
                await message.edit({ components: [] });
            } catch (e) {
                console.error("Failed to remove buttons after collector ended:", e);
            }
        });
    });
};

function formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}m ${seconds}s`;
}
