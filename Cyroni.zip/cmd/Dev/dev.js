const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");

const devPath = path.join(__dirname, "../../database/dev.js");
const ownersPath = path.join(__dirname, "../../database/owners.js");

function loadDevs() {
    delete require.cache[require.resolve(devPath)];
    return require(devPath);
}

function saveDevs(devs) {
    fs.writeFileSync(devPath, `module.exports = ${JSON.stringify(devs, null, 4)};\n`);
}

function loadOwners() {
    delete require.cache[require.resolve(ownersPath)];
    return require(ownersPath);
}

function extractId(input) {
    if (!input) return null;
    const match = input.match(/^<@!?(\d+)>$/);
    if (match) return match[1];
    if (/^\d+$/.test(input)) return input;
    return null;
}

module.exports = {
    name: "dev",
    description: "Manage developer list (add/remove/list)",
    async execute(client, message, args) {
        const owners = loadOwners();

        if (!owners.includes(message.author.id)) {
            const embed = new EmbedBuilder()
                .setTitle("Access Denied")
                .setDescription("You are not authorized to use this command.");
            return message.reply({ embeds: [embed] });
        }

        const devs = loadDevs();
        const subcommand = args[0];

        if (!subcommand) {
            const embed = new EmbedBuilder()
                .setTitle("Missing Arguments")
                .setDescription("Usage: `dev add <user>`, `dev remove <user>`, or `dev list`");
            return message.reply({ embeds: [embed] });
        }

        if (subcommand === "add") {
            const idToAdd = extractId(args[1]);
            if (!idToAdd) {
                const embed = new EmbedBuilder()
                    .setTitle("Missing User")
                    .setDescription("Please provide a user mention or ID to add.");
                return message.reply({ embeds: [embed] });
            }

            if (devs.includes(idToAdd)) {
                const embed = new EmbedBuilder()
                    .setTitle("Already a Developer")
                    .setDescription(`<@${idToAdd}> is already in the developer list.`);
                return message.reply({ embeds: [embed] });
            }

            devs.push(idToAdd);
            saveDevs(devs);

            const embed = new EmbedBuilder()
                .setTitle("Developer Added")
                .setDescription(`<@${idToAdd}> has been added to the developer list.`);
            return message.reply({ embeds: [embed] });
        }

        if (subcommand === "remove") {
            const idToRemove = extractId(args[1]);
            if (!idToRemove) {
                const embed = new EmbedBuilder()
                    .setTitle("Missing User")
                    .setDescription("Please provide a user mention or ID to remove.");
                return message.reply({ embeds: [embed] });
            }

            if (!devs.includes(idToRemove)) {
                const embed = new EmbedBuilder()
                    .setTitle("Not a Developer")
                    .setDescription(`<@${idToRemove}> is not in the developer list.`);
                return message.reply({ embeds: [embed] });
            }

            const updatedDevs = devs.filter(id => id !== idToRemove);
            saveDevs(updatedDevs);

            const embed = new EmbedBuilder()
                .setTitle("Developer Removed")
                .setDescription(`<@${idToRemove}> has been removed from the developer list.`);
            return message.reply({ embeds: [embed] });
        }

        if (subcommand === "list") {
            const list = devs.length
                ? devs.map(id => `<@${id}>`).join("\n")
                : "No developers found.";

            const embed = new EmbedBuilder()
                .setTitle("Developer List")
                .setDescription(list);

            return message.channel.send({ embeds: [embed] });
        }

        const embed = new EmbedBuilder()
            .setTitle("Invalid Subcommand")
            .setDescription("Use: `add`, `remove`, or `list`");
        return message.reply({ embeds: [embed] });
    }
};
