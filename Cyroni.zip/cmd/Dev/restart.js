const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const owners = require('../../database/owners.js');

module.exports = {
  name: 'restart',
  description: 'Restarts the bot (owners only)',

  async execute(client, message, args) {
    if (!message?.author?.id || !owners.includes(message.author.id)) {
      return message?.reply?.('You do not have permission to use this command.')?.catch(() => {});
    }

    console.log(`Restart command triggered by ${message.author.tag}`);

    const embed = new EmbedBuilder()
      .setTitle('Confirm Restart')
      .setDescription('Are you sure you want to restart the bot?');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_restart')
        .setLabel('Confirm')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancel_restart')
        .setLabel('Cancel')
        .setStyle(ButtonStyle.Secondary)
    );

    const sent = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = (i) => i.user.id === message.author.id;
    const collector = sent.createMessageComponentCollector({
      filter,
      time: 15000,
      max: 1
    });

    collector.on('collect', async (interaction) => {
      if (interaction.customId === 'confirm_restart') {
        await interaction.update({
          content: 'Restarting bot...',
          components: [],
          embeds: []
        });
        process.exit(0);
      } else {
        await interaction.update({
          content: 'Restart cancelled.',
          components: [],
          embeds: []
        });
      }
    });

    collector.on('end', async (collected) => {
      if (collected.size === 0) {
        await sent.edit({
          content: 'Restart timed out.',
          components: [],
          embeds: []
        });
      }
    });
  }
};