const {
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ButtonBuilder,
    ButtonStyle,
    ComponentType
} = require("discord.js");
const ms = require("ms");
const fs = require("fs");
const path = require("path");

const devs = require("../../database/dev.js");
const emoji = require("../../emojis.js");

const npPath = path.join(__dirname, "../../database/np.json");
let npData = fs.existsSync(npPath) ? JSON.parse(fs.readFileSync(npPath, "utf8")) : {};

module.exports = {
    name: "np",
    description: "Manage users with no-prefix access (add, remove, list)",
    usage: "<add|remove|list> [@user]",

    async execute(client, message, args) {
        if (!devs.includes(message.author.id)) {
            return message.reply(`${emoji.cross} Only authorized developers can use this command.`);
        }

        const sub = args[0];

        if (sub === "add") {
            const user = message.mentions.users.first();
            if (!user) return message.reply(`${emoji.cross} Please mention a user to grant no-prefix access.`);

            const embed = new EmbedBuilder()
                .setTitle("Select No Prefix Tier")
                .setDescription(`Choose the no prefix tier for **${user.tag}**`)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setFooter({ text: "No Prefix Access Control" });

            const select = new StringSelectMenuBuilder()
                .setCustomId("np_tier")
                .setPlaceholder("Select a Tier")
                .addOptions([
                    { label: "Wood (1 min)", value: "wood" },
                    { label: "Bronze (1 day)", value: "bronze" },
                    { label: "Silver (1 week)", value: "silver" },
                    { label: "Gold (1 month)", value: "gold" },
                    { label: "Diamond (1 year)", value: "diamond" },
                    { label: "Godess (Permanent)", value: "godess" },
                    { label: "Custom Time", value: "custom" }
                ]);

            const row = new ActionRowBuilder().addComponents(select);
            const reply = await message.reply({ embeds: [embed], components: [row] });

            const collector = reply.createMessageComponentCollector({
                componentType: ComponentType.StringSelect,
                time: ms("2m"),
                filter: i => i.user.id === message.author.id
            });

            collector.on("collect", async (interaction) => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: `${emoji.cross} Only **${message.author.username}** can use this.`, ephemeral: true });
                }

                const choice = interaction.values[0];

                if (choice === "custom") {
                    const modal = new ModalBuilder()
                        .setCustomId("np_custom_modal")
                        .setTitle("Custom Duration");

                    const durationInput = new TextInputBuilder()
                        .setCustomId("np_duration")
                        .setLabel("Duration (e.g. 5m, 1h, 2d)")
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                        .setPlaceholder("e.g. 10min");

                    modal.addComponents(new ActionRowBuilder().addComponents(durationInput));
                    await interaction.showModal(modal);

                    const modalSubmit = await interaction.awaitModalSubmit({
                        filter: i => i.user.id === message.author.id,
                        time: ms("1m")
                    }).catch(() => null);

                    if (!modalSubmit) return;

                    const durationRaw = modalSubmit.fields.getTextInputValue("np_duration");
                    const durationMs = ms(durationRaw);
                    if (!durationMs || isNaN(durationMs) || durationMs < 1000) {
                        return modalSubmit.reply({ content: `${emoji.cross} Invalid duration format.`, ephemeral: true });
                    }

                    npData[user.id] = { time: Date.now() + durationMs };
                    fs.writeFileSync(npPath, JSON.stringify(npData, null, 2));
                    try {
                        await user.send(`You have been granted **no-prefix access** for \`${durationRaw}\`!`);
                    } catch {}

                    await modalSubmit.reply({
                        content: `${emoji.tick} **${user.tag}** now has no-prefix access for \`${durationRaw}\`!`,
                        ephemeral: true
                    });

                    await reply.edit({ components: [] }).catch(() => {});
                    collector.stop();
                    return;
                }

                let duration = null;
                switch (choice) {
                    case "wood": duration = ms("1m"); break;
                    case "bronze": duration = ms("1d"); break;
                    case "silver": duration = ms("7d"); break;
                    case "gold": duration = ms("30d"); break;
                    case "diamond": duration = ms("365d"); break;
                    case "godess": duration = null; break;
                }

                npData[user.id] = {
                    time: duration ? Date.now() + duration : null
                };

                fs.writeFileSync(npPath, JSON.stringify(npData, null, 2));
                try {
                    await user.send(`You have been granted **no-prefix access**${duration ? ` for \`${choice.toUpperCase()}\`` : " permanently"}!`);
                } catch {}

                await interaction.update({
                    content: `${emoji.tick} **${user.tag}** now has **${choice.toUpperCase()}** no-prefix access!`,
                    embeds: [],
                    components: []
                });

                collector.stop();
            });

            collector.on("end", () => {
                if (!reply.deleted) reply.edit({ components: [] }).catch(() => {});
            });
        }

        else if (sub === "list") {
            const entries = Object.entries(npData);
            if (entries.length === 0) {
                return message.reply("⚠ No users are in the no-prefix list.");
            }

            const itemsPerPage = 10;
            let currentPage = 1;
            const totalPages = Math.ceil(entries.length / itemsPerPage);

            const fetchUserLines = async (list, startIndex) => {
                return await Promise.all(list.map(async ([userID, data], i) => {
                    const index = startIndex + i + 1;
                    let username;
                    try {
                        const user = await client.users.fetch(userID);
                        username = `[${user.username}](https://discord.com/users/${user.id})`;
                    } catch {
                        username = "**Unknown User**";
                    }

                    let timeLeft = "∞";
                    if (data.time) {
                        const remaining = data.time - Date.now();
                        timeLeft = remaining > 0 ? ms(remaining, { long: true }) : "Expired";
                    }

                    return `\`${index}.\` ${username} [ID: \`${userID}\`] - ⏳ \`${timeLeft}\``;
                }));
            };

            const generateEmbed = async (page) => {
                const start = (page - 1) * itemsPerPage;
                const end = Math.min(start + itemsPerPage, entries.length);
                const current = entries.slice(start, end);
                const lines = await fetchUserLines(current, start);

                return new EmbedBuilder()
                    .setTitle(`No Prefix Users (${entries.length} total)`)
                    .setDescription(lines.join("\n"))
                    .setFooter({ text: `Page ${page}/${totalPages}` });
            };

            const createButtons = (page) => {
                return new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("np_prev")
                        .setLabel("Previous")
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(page === 1),
                    new ButtonBuilder()
                        .setCustomId("np_delete")
                        .setLabel("Delete")
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId("np_next")
                        .setLabel("Next")
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(page === totalPages)
                );
            };

            const msg = await message.reply({
                embeds: [await generateEmbed(currentPage)],
                components: totalPages > 1 ? [createButtons(currentPage)] : []
            });

            if (totalPages > 1) {
                const filter = i => i.user.id === message.author.id;
                const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

                collector.on("collect", async interaction => {
                    if (interaction.user.id !== message.author.id) {
                        return interaction.reply({ content: `${emoji.cross} Only **${message.author.username}** can use this.`, ephemeral: true });
                    }

                    if (interaction.customId === "np_prev" && currentPage > 1) currentPage--;
                    else if (interaction.customId === "np_next" && currentPage < totalPages) currentPage++;
                    else if (interaction.customId === "np_delete") {
                        await msg.delete().catch(() => {});
                        return collector.stop();
                    }

                    await interaction.update({
                        embeds: [await generateEmbed(currentPage)],
                        components: [createButtons(currentPage)]
                    });
                });

                collector.on("end", () => {
                    if (!msg.deleted) {
                        msg.edit({ components: [] }).catch(() => {});
                    }
                });
            }
        }

        else if (sub === "remove") {
            const user = message.mentions.users.first();
            if (!user) return message.reply(`${emoji.cross} Please mention a user to remove from no-prefix list.`);

            if (!npData[user.id]) {
                return message.reply("⚠ This user is not in the no-prefix list.");
            }

            delete npData[user.id];
            fs.writeFileSync(npPath, JSON.stringify(npData, null, 2));

            try {
                await user.send(`⚠️ Your no-prefix access has been removed by **${message.author.tag}**.`);
            } catch {}
            message.reply(`${emoji.tick} **${user.tag}** must now use the prefix for commands.`);
        }

        else {
            return message.reply(`${emoji.cross} Invalid usage. Use \`np add @user\`, \`np remove @user\`, or \`np list\`.`);
        }
    }
};
