const path = require("path");
const emojis = require("../../emojis.js"); 
const owners = require(path.join(__dirname, "../../database/owners.js"));
const util = require("util");

module.exports = {
  name: "jsk",
  description: "Owner-only JavaScript eval command",
  async execute(client, message, args) {
    if (!owners.includes(message.author.id)) {
      return message.reply("<a:CH_PepeFuckOff:1381514538955964436>");
    }

    if (!args.length) {
      return message.reply("Please provide JavaScript code to evaluate.");
    }

    const code = args.join(" ");

    try {
      let result = eval(code);
      if (result instanceof Promise) result = await result;

      if (typeof result !== "string") {
        result = util.inspect(result, { depth: 1 });
      }

      if (result.length > 1500) {
        result = result.slice(0, 1500) + "... (truncated)";
      }

      await message.react(emojis.tick);

      return message.reply(
        `\`\`\`js\n${result}\n\`\`\``
      );
    } catch (error) {
      await message.react(emojis.error);

      return message.reply(`\`\`\`js\n${error.message}\n\`\`\``);
    }
  },
};