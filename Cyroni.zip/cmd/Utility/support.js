const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "support",
    aliases: ["hq"],
    description: "Get the support server link.",

    async execute(client, message) {
        const embed = new EmbedBuilder()
            .setTitle("Support Server")
            .setDescription("Need help or have questions?\nJoin our support server:\n[Click to Join](https://discord.gg/zZKSSMWagY)")
            .setFooter({ text: "Harmonia HQ Support ❤️" });

        message.channel.send({ embeds: [embed] });
    }
};