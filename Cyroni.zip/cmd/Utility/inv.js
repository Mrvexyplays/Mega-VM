const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "invite",
    aliases: ["inv"],
    description: "Get the bot's invite link.",

    async execute(client, message) {
        const admin = `https://discord.com/oauth2/authorize?client_id=1409051024936669184&scope=bot&permissions=275955084377`;
        const req = `https://discord.com/oauth2/authorize?client_id=1409051024936669184&scope=bot&permissions=276491954768`

        const embed = new EmbedBuilder()
            .setTitle("Invite Harmonia")
            .setDescription(`> <:dot:1380133992929562766> Invite With Admin Permissions **[Click Here](${admin})**\n> <:dot:1380133992929562766> Invite With Sufficient Permissions **[Click Here](${req})**`)

        message.channel.send({ embeds: [embed] });
    }
};