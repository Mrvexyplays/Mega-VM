const fs = require("fs");
const path = require("path");
const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  ComponentType
} = require("discord.js");
const { createCanvas, loadImage } = require("@napi-rs/canvas");

const ITEMS_PER_PAGE = 6;
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const COMMANDS_ROOT = path.join(__dirname, "../", "../", "cmd");

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function clipCircle(ctx, x, y, r) {
  ctx.beginPath();
  ctx.arc(x + r, y + r, r, 0, Math.PI * 2, false);
  ctx.clip();
}

class HelpCanvas {
  constructor() {
    this.canvas = createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
    this.ctx = this.canvas.getContext("2d");
  }

  async drawBackground() {
    const ctx = this.ctx;
    const w = CANVAS_WIDTH;
    const h = CANVAS_HEIGHT;
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, "#001F3F");
    gradient.addColorStop(1, "#000814");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(0, 200, 255, 0.08)";
    roundRect(ctx, 30, 30, w - 60, h - 60, 20);
    ctx.fill();
    ctx.strokeStyle = "rgba(0, 200, 255, 0.15)";
    ctx.lineWidth = 2;
    roundRect(ctx, 30, 30, w - 60, h - 60, 20);
    ctx.stroke();
  }

  async drawHeader(client, title) {
    const ctx = this.ctx;
    const x = 40;
    const y = 40;
    const width = CANVAS_WIDTH - 80;
    const height = 80;
    ctx.fillStyle = "rgba(0, 50, 100, 0.85)";
    roundRect(ctx, x, y, width, height, 18);
    ctx.fill();
    ctx.font = "bold 28px Arial";
    ctx.fillStyle = "#00e6ff";
    ctx.textAlign = "center";
    ctx.fillText(title, CANVAS_WIDTH / 2, y + 50);

    try {
      const avatar = await loadImage(
        client.user.displayAvatarURL({ extension: "png", size: 128 })
      );
      ctx.save();
      clipCircle(ctx, x + 15, y + 10, 35);
      ctx.drawImage(avatar, x + 15, y + 10, 70, 70);
      ctx.restore();
    } catch {}
  }

  drawCategories(categories) {
    const ctx = this.ctx;
    const startY = 140;
    const boxHeight = 60;
    const boxWidth = 700;
    const centerX = (CANVAS_WIDTH - boxWidth) / 2;
    categories.forEach((cat, i) => {
      if (cat.toLowerCase() === "dev") return;
      const y = startY + i * (boxHeight + 15);
      ctx.fillStyle = "rgba(0, 150, 255, 0.07)";
      roundRect(ctx, centerX, y, boxWidth, boxHeight, 15);
      ctx.fill();
      ctx.strokeStyle = "rgba(0, 180, 255, 0.2)";
      ctx.lineWidth = 1;
      roundRect(ctx, centerX, y, boxWidth, boxHeight, 15);
      ctx.stroke();
      ctx.font = "bold 22px Arial";
      ctx.fillStyle = "#00d9ff";
      ctx.textAlign = "left";
      ctx.fillText(cat.charAt(0).toUpperCase() + cat.slice(1), centerX + 25, y + 38);
      const commandsCount = fs
        .readdirSync(path.join(COMMANDS_ROOT, cat))
        .filter((f) => f.endsWith(".js")).length;
      ctx.font = "16px Arial";
      ctx.fillStyle = "#99faff";
      ctx.textAlign = "right";
      ctx.fillText(`${commandsCount} commands`, centerX + boxWidth - 25, y + 38);
    });
  }

  drawCommands(commands, startY = 140) {
    const ctx = this.ctx;
    commands.forEach((cmd, i) => {
      if (i >= ITEMS_PER_PAGE) return;
      const y = startY + i * 60;
      ctx.font = "20px Arial";
      ctx.fillStyle = "#a0eaff";
      ctx.textAlign = "left";
      ctx.fillText(`• ${cmd.name}`, 55, y);
      ctx.font = "14px Arial";
      ctx.fillStyle = "#66d9ef";
      const desc = cmd.description.length > 70 ? cmd.description.slice(0, 67) + "..." : cmd.description;
      ctx.fillText(`> ${desc}`, 75, y + 20);
    });
  }

  drawFooter(text) {
    const ctx = this.ctx;
    ctx.font = "16px Arial";
    ctx.textAlign = "center";
    ctx.fillStyle = "#33ccff";
    ctx.fillText(text, CANVAS_WIDTH / 2, CANVAS_HEIGHT - 30);
  }

  drawPageIndicator(current, total) {
    const ctx = this.ctx;
    ctx.font = "14px Arial";
    ctx.textAlign = "right";
    ctx.fillStyle = "#33ccff";
    ctx.fillText(`Page ${current} / ${total}`, CANVAS_WIDTH - 40, CANVAS_HEIGHT - 30);
  }

  getBuffer() {
    return this.canvas.toBuffer("image/png");
  }
}

module.exports = {
  name: "help2",
  aliases: ["h2"],
  description: "Show help menu",
  async execute(client, message, args) {
    const categories = fs
      .readdirSync(COMMANDS_ROOT)
      .filter((f) => !f.includes(".") && fs.statSync(path.join(COMMANDS_ROOT, f)).isDirectory())
      .filter((cat) => cat.toLowerCase() !== "dev");

    let selectedCategory = args[0]?.toLowerCase() || null;
    let commands = [];

    if (selectedCategory && !categories.includes(selectedCategory)) selectedCategory = null;

    if (selectedCategory) {
      commands = fs
        .readdirSync(path.join(COMMANDS_ROOT, selectedCategory))
        .filter((f) => f.endsWith(".js"))
        .map((file) => {
          const cmd = require(path.join(COMMANDS_ROOT, selectedCategory, file));
          return {
            name: cmd.name || file.replace(".js", ""),
            description: cmd.description || "No description",
          };
        });
    }

    const totalPages = selectedCategory ? Math.ceil(commands.length / ITEMS_PER_PAGE) : 1;
    const canvas = new HelpCanvas();

    if (!selectedCategory) {
      await canvas.drawBackground();
      await canvas.drawHeader(client, `${client.user.username} Help Menu`);
      canvas.drawCategories(categories);
      canvas.drawFooter("Made with ❤️ by Harmonia Team");

      const attachment = new AttachmentBuilder(canvas.getBuffer(), { name: "help.png" });
      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId("help_category_select")
        .setPlaceholder("Select a category")
        .addOptions([
          { label: "Home", description: "Back to home menu", value: "home" },
          ...categories.map((cat) => ({
            label: cat.charAt(0).toUpperCase() + cat.slice(1),
            description: `View ${cat} commands`,
            value: cat,
          })),
        ]);

      const row = new ActionRowBuilder().addComponents(selectMenu);
      const sent = await message.channel.send({ files: [attachment], components: [row] });

      const collector = sent.createMessageComponentCollector({ componentType: ComponentType.StringSelect, time: 300_000 });
      let currentSelectedCategory = null;
      let page = 1;

      collector.on("collect", async (i) => {
        if (i.user.id !== message.author.id)
          return i.reply({ content: "You can't use this menu.", ephemeral: true });

        await i.deferUpdate();
        if (i.customId === "help_category_select") {
          const val = i.values[0];
          if (val === "home") {
            currentSelectedCategory = null;
            page = 1;
            await canvas.drawBackground();
            await canvas.drawHeader(client, `${client.user.username} Help Menu`);
            canvas.drawCategories(categories);
            canvas.drawFooter("Made with ❤️ by Harmonia Team");
            const att = new AttachmentBuilder(canvas.getBuffer(), { name: "help.png" });
            return await i.editReply({ files: [att], components: [row] });
          } else {
            currentSelectedCategory = val;
            page = 1;
            commands = fs
              .readdirSync(path.join(COMMANDS_ROOT, val))
              .filter((f) => f.endsWith(".js"))
              .map((file) => {
                const cmd = require(path.join(COMMANDS_ROOT, val, file));
                return {
                  name: cmd.name || file.replace(".js", ""),
                  description: cmd.description || "No description",
                };
              });

            await canvas.drawBackground();
            await canvas.drawHeader(client, `${val.charAt(0).toUpperCase() + val.slice(1)} Commands`);
            canvas.drawCommands(commands.slice(0, ITEMS_PER_PAGE));
            canvas.drawPageIndicator(page, Math.ceil(commands.length / ITEMS_PER_PAGE));
            canvas.drawFooter(`${commands.length} commands in this category`);
            const att = new AttachmentBuilder(canvas.getBuffer(), { name: "help.png" });

            const prevBtn = new ButtonBuilder()
              .setCustomId("prev_page")
              .setEmoji("<:lockleft:1386294395351072891>")
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(true);

            const nextBtn = new ButtonBuilder()
              .setCustomId("next_page")
              .setEmoji("<:lockright:1386294496475480165>")
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(commands.length <= ITEMS_PER_PAGE);

            const buttonsRow = new ActionRowBuilder().addComponents(prevBtn, nextBtn);
            return await i.editReply({ files: [att], components: [row, buttonsRow] });
          }
        }
      });

      const buttonCollector = sent.createMessageComponentCollector({ componentType: ComponentType.Button, time: 300_000 });

      buttonCollector.on("collect", async (btn) => {
        if (btn.user.id !== message.author.id)
          return btn.reply({ content: "You can't use these buttons.", ephemeral: true });

        if (!currentSelectedCategory) return;
        if (btn.customId === "prev_page" && page > 1) page--;
        if (btn.customId === "next_page" && page < Math.ceil(commands.length / ITEMS_PER_PAGE)) page++;

        await canvas.drawBackground();
        await canvas.drawHeader(client, `${currentSelectedCategory.charAt(0).toUpperCase() + currentSelectedCategory.slice(1)} Commands`);
        const pageCommands = commands.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);
        canvas.drawCommands(pageCommands);
        canvas.drawPageIndicator(page, Math.ceil(commands.length / ITEMS_PER_PAGE));
        canvas.drawFooter(`${commands.length} commands in this category`);
        const att = new AttachmentBuilder(canvas.getBuffer(), { name: "help.png" });

        const prevBtn = new ButtonBuilder()
          .setCustomId("prev_page")
          .setEmoji("<:lockleft:1386294395351072891>")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(page === 1);

        const nextBtn = new ButtonBuilder()
          .setCustomId("next_page")
          .setEmoji("<:lockright:1386294496475480165>")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(page === Math.ceil(commands.length / ITEMS_PER_PAGE));

        const buttonsRow = new ActionRowBuilder().addComponents(prevBtn, nextBtn);
        await btn.update({ files: [att], components: [row, buttonsRow] });
      });

      return;
    }

    await canvas.drawBackground();
    await canvas.drawHeader(client, `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Commands`);
    const pageCommands = commands.slice(0, ITEMS_PER_PAGE);
    canvas.drawCommands(pageCommands);
    canvas.drawPageIndicator(1, totalPages);
    canvas.drawFooter(`${commands.length} commands in this category`);
    const attachment = new AttachmentBuilder(canvas.getBuffer(), { name: "help.png" });
    await message.channel.send({ files: [attachment] });
  }
};