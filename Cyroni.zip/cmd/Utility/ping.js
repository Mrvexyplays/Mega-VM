const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "ping",
    description: "Shows bot and API latency.",

    async execute(client, message) {
        const sent = await message.channel.send("Pinging...");

        const apiLatency = Math.round(client.ws.ping);

        const embed = new EmbedBuilder()
            .setDescription(`**<:dot:1380133992929562766> Bot Latency:** \`${apiLatency}ms\``)


        sent.edit({ content: "", embeds: [embed] });
    }
};