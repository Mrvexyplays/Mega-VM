const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "autoplay",
    description: "Toggle autoplay on/off",
    aliases: ["ap"],

    async execute(client, message) {
        const player = client.riffy.players.get(message.guild.id);

        if (!player) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                
                        .setDescription('<:lockcross:1380161154684293161> No music is currently playing.')
                ]
            });
        }

        player.isAutoplay = !player.isAutoplay;

        const embed = new EmbedBuilder()
            
            .setDescription(
                player.isAutoplay 
                ? '<:locktick:1380161476706177116> Autoplay has been **enabled**.' 
                : '<:lockcross:1380161154684293161> Autoplay has been **disabled**.'
            );

        message.channel.send({ embeds: [embed] });
    },
};