const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "stop",
    aliases: ["st"],
    description: "Stop playback and leave voice channel.",
    async execute(client, message) {
        const player = client.riffy.players.get(message.guild.id);

        if (!player) {
            const noMusicEmbed = new EmbedBuilder()
                .setTitle("No Music Playing")
                .setDescription("<:lockcross:1380161154684293161> No music is currently playing.");
            return message.channel.send({ embeds: [noMusicEmbed] });
        }

        player.destroy();

        const stoppedEmbed = new EmbedBuilder()
            .setDescription("<:locktick:1380161476706177116> Stopped the music and left the voice channel.");
        message.channel.send({ embeds: [stoppedEmbed] });
    }
};
