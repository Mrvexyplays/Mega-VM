module.exports = {
    token: "MTM2MzM4NTM4MjY3NDM3MDY2MQ.G-3ucW.TBtTg32NPVYk_nDuvNDVPymE_l5LsMHUuPRFIg",
    prefix: "!", // Or your preferred prefix
    ownerId: ["1287395528816201769"], // Your Discord User ID
    // Add other configurations as needed
};